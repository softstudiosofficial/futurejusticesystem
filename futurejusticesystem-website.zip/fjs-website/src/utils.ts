// Two-letter initials for panelist avatars, ignoring titles.
const SKIP = new Set(['Barrister', 'Justice', 'Dr', 'Mian', 'Muhammad', '(R)']);
export function initials(name: string): string {
  const words = name.replace(/\./g, '').split(/\s+/).filter((w) => !SKIP.has(w));
  if (words.length > 1) return (words[0][0] + words[words.length - 1][0]).toUpperCase();
  return (words[0] ?? '').slice(0, 2).toUpperCase();
}
